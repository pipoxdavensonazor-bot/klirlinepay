# KlirPay Global — Master MVP (sandbox)

Plateforme d orchestration de paiements B2B, corridor Canada Haiti, extensible USA Caraibes Latam Afrique Europe.

Principes : stablecoin = rail optionnel, jamais de coin maison. Sandbox etiquete, jamais d argent reel. Ledger double-entree = source de verite. Isolation tenant imposee cote backend emulateur. Confirmation humaine obligatoire pour tout flux financier agentique.

Modules : auth RBAC + 2FA-ready, orgs multi-tenant, onboarding KYB, wallets CAD USD HTG + USDC USDT prets, ledger immuable, clients, beneficiaires masques, factures avec calcul serveur, liens #pay, moteur Bank Card Mobile Stablecoin a providers remplacables, idempotence, remboursements, payouts, FX avec devis expires, router, risque 0-100, webhooks signes avec retry, API v1 avec cles sandbox prod, admin, audit, observabilite, IA sur donnees reelles isolees + agent avec confirmation, analytique.

Tests : onglet Tests 75 -> AC-001 a AC-075 + E2E + recovery + integrite financiere + isolation tenant + idempotence 10x.

Dernier rapport : 75/75 PASS, 100 %, statut READY FOR SANDBOX. Certification Sandbox : 7/7 CERTIFIE (ledger source de verite, zero doublon paiement/webhook, isolation tenant serveur, sandbox separe + prod verrouillee sans prestataire reel, IA avec confirmation humaine, providers remplacables, router transparent). Regle maintenue : production reelle exige prestataires conformes + revue legale.
Regle : 75/75 sinon MVP NOT COMPLETE. Production reelle exige prestataires conformes + revue legale.

Donnees : localStorage klirpay_master_v2. Demo owner@demo.klir / Demo1234!. Bouton Reinitialiser dans Reglages.

Logo : src/logo.png (fourni par le fondateur, detoure du TIF original), affiche sidebar + login + page de paiement.
Design system : tokens #0EA2CD / #003B69 / #F7FAFC / #FFFFFF, 70/20/10, homepage hero, sidebar par groupes, dashboard hero + 4 actions, paiement avec resume et confirmation explicite, bottom nav mobile, statuts avec pastille + texte.
Grand public : checklist 5 etapes, liens de paiement + QR (lib inline), sandbox guide, webhooks, aide/FAQ, notifications, equipe par role, securite (2FA, reset passe, verification email), exports CSV, historique client, tarifs sur la homepage.
Espace client : entreprises voient tout dans Clients + Admin. Bouton Acces genere un code KP-XXXXXX par client ; le client touche Espace client sur l accueil, cree son compte et paie ses factures (portail Mes factures, navigation restreinte, isolation par dossier).
Utilisateurs visibles dans Admin (tous comptes + tous clients). Historique local au navigateur : changer de telephone = Reglages, Sauvegarde, Exporter puis Importer le JSON sur l autre appareil.